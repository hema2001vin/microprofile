package com.example;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class MSApp extends Application {

	public MSApp() {
		System.out.println("INFO ==========> Quotes App initialized!!");
	}
	
}
