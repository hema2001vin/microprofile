package com.example;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/quotes")
@ApplicationScoped
public class QuoteMS {
	
	String[] quotes = {"Life is Cool","Life is fun","Life needs friends","Life is a one time offer just live it"};
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String currentQuote() {
		System.out.println("INFO ==========> Inside QuoteMS.currentQuote()!!");
		int idx = (int)(Math.floor(Math.random() * quotes.length));
		return quotes[idx];
	}
}
